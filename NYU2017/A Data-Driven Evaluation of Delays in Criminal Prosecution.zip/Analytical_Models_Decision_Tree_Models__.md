# Analytical Models

## Decision Tree Models
We chose to use  decision tree-based models to build a classifier that predicts whether a given case would be disposed within a year or not. Decision trees are considered one of the most versatile machine learning methods \cite{James_2013}. 